﻿using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading;

namespace ClassesPractice
{
    class Person
    {

        private DateTime birthday;

        public Guid ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public Person(string firstName,string lastName, DateTime birthday)
        {
            this.birthday = birthday;
            FirstName = firstName;
            LastName = lastName;
            ID = Guid.NewGuid();
        }

        public DateTime Birthday 
        { 
            get
            {
                return birthday;
            }
            set
            {
                DateTime minDate = DateTime.Today.AddYears(-110);
                DateTime maxDate = DateTime.Today;

                if (value < minDate || value > maxDate )
                {
                    throw new ArgumentException("That birthdate is not valid.");
                }

                birthday = value;
            }
        }


      public string FullName
        {
            get { return FirstName + " " + LastName; }
        }

        public int Age
        {
            get { return (int) (DateTime.Today - birthday).TotalDays / 365; }
        }

        public int GetDaysUntilBirthday()
        {
            int bdayMonth = birthday.Month;
            int bdayDay = birthday.Day;
            int bdayYear = 0;
            DateTime today = DateTime.Today;

            if (bdayMonth > today.Month)
            {
                bdayYear = today.Year;
            }
            else if (bdayMonth < today.Month)
            {
                bdayYear = today.Year + 1;
            }
            else if (bdayDay == today.Day) // Bday month is this month
            {
                return 0;
            }
            else if (bdayDay > today.Day)
            {
                bdayYear = today.Year;
            }
            else
            {
                bdayYear = today.Year + 1;
            }

            DateTime nextBirthday = new DateTime(bdayYear, bdayMonth, bdayDay);

            return (int) (nextBirthday - today).TotalDays;

        }





    }
}
