﻿using System;
using System.Collections.Generic;
using System.Dynamic;

namespace ClassesPractice
{
    class Program
    {
        static void Main(string[] args)
        {

            Athlete gymRat = new Athlete("Sven", 200);

            Dictionary<string,Exercise> workout = new Dictionary<string,Exercise>();

            Exercise burpees = new Exercise("burpees", 12, 5);
            Exercise squats = new Exercise("squats", 5, 2);
            Exercise jumpRope = new Exercise("jumpRope", 20, 8);

            workout.Add(burpees.Name,burpees);
            workout.Add(squats.Name,squats);
            workout.Add(jumpRope.Name,jumpRope);

            int maxHR = 175, minHR = 120;

            // Ask for exercise name 
            string input = "jumpRope";

            Exercise selectedExercise = new Exercise() ;

            foreach (var item in workout)
            {
                if (item.Key == input)
                {
                    selectedExercise = item.Value;
                }
            }
            // Ask for number of minutes
            int minutes = 20;
            

            for (int i = 1; i <  minutes + 1; i++)
            {
                gymRat.UpdateCaloriesBurned(selectedExercise.CaloriesPerMinute);
                Console.WriteLine($"{gymRat.Name} has burned {gymRat.CaloriesBurned} calories.");
                gymRat.UpdateHeartRate(selectedExercise.HeartRateAdjustment);
                Console.WriteLine($"{gymRat.Name} has a heartrate of {gymRat.CurrentHeartRate}");

                if (gymRat.CurrentHeartRate >= maxHR)
                {
                    Console.WriteLine($"{gymRat.Name} is about to die. Ending workout!!!");
                    break;
                }
            }

            if (gymRat.CaloriesBurned >= gymRat.DailyCalorieGoal)
            {
                Console.WriteLine($"{gymRat.Name} completed the goal.");
            }
            else
            {
                Console.WriteLine($"{gymRat.Name} is a loser and a quitter.");
            }


            AppHelper.PauseGame();

 

     

            AppHelper.ExitGame();

            //Person katie = new Person("Katie", "SZ>>>>>>", new DateTime(1998, 9, 20));
            //Person kate = new Person("Kate", "Preston", new DateTime(1994, 11, 4));

            //List<Person> people = new List<Person>() { kate, katie };

            //foreach (Person person in people)
            //{
            //    Console.WriteLine($"{person.FullName} is {person.Age} with a birthday in {person.GetDaysUntilBirthday()} days.");
            //}


        }
    }
}
