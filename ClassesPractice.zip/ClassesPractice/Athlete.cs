﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassesPractice
{
    class Athlete
    {

        public Guid ID { get; set; }

        public string Name { get; set; }

        public int DailyCalorieGoal { get; set; }

        public int CaloriesBurned
        {
            get; private set;
        }

        public int CurrentHeartRate { get; private set; }


        public Athlete(string name, int calorieGoal)
        {
            Name = name;
            DailyCalorieGoal = calorieGoal;
            ID = Guid.NewGuid();
            CaloriesBurned = 0;
            CurrentHeartRate = 85;
        }

        public void UpdateHeartRate(int value)
        {   
            CurrentHeartRate = CurrentHeartRate + value;
        }

        public void UpdateCaloriesBurned(int value)
        {
            if (value < 1)
            {
                throw new ArgumentException("Calories value must be at least 1");
            }

            CaloriesBurned = CaloriesBurned + value;
        }

        public bool WasGoalMet()
        {
            if (CaloriesBurned >= DailyCalorieGoal)
            {
                return true;
            }

            return false;
        }
    }
}
