﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassesPractice
{

    static class CFL
    {
        public static void DisplayColoredText(string text, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(text);
            Console.ForegroundColor = ConsoleColor.Gray;
        }


        public static string GetTrimLowerString(string text)
        {
            return text.Trim().ToLower();
        }


    }
}
