﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassesPractice
{
   static class AppHelper
    {

        public static void PauseGame()
        {
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        public  static void ExitGame()
        {
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
