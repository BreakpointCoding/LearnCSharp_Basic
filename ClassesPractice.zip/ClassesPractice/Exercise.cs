﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassesPractice
{
    class Exercise
    {
        private int caloriesPerMinute;
        private int heartRateAdjustment;
        public Guid ID { get; set; }

        public string Name { get; set; }

        public bool IsActive { get; set; }

        public int CaloriesPerMinute
        {
            get
            {
                return caloriesPerMinute;
            }
            set
            {
                if (value < 1)
                {
                    throw new ArgumentException("Calories per minute must be greater than zero");
                }
                caloriesPerMinute = value;
            }
        }

        public int HeartRateAdjustment
        { 
            get
            {
                return heartRateAdjustment;
            }
            set
            {
                if (value < 1)
                {
                    throw new ArgumentException("Heart rate adjustment must be greater than zero");
                }
                heartRateAdjustment = value;
            }
        }

        public Exercise()
        {


        }
        public Exercise(string name, int calories, int heartRate)
        {
            Name = name;
            HeartRateAdjustment = heartRate;
            CaloriesPerMinute = calories;
            IsActive = false;

            ID = Guid.NewGuid();
        }

        public void SwitchActiveFlag()
        {
            IsActive = !IsActive;         
        }
    }
}
